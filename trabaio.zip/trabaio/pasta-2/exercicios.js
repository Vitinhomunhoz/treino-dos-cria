//exe1
function exer1(){
let n1 = Number(document.getElementById ("n1").value)
let n2 = Number(document.getElementById ("n2").value)
let r = (n1-n2)
alert(r , "o resultado será: " )
}
//exe2
function exe2(){
    let n1= Number(document.getElementById("n1").value)
    let n2= Number(document.getElementById("n2").value)
    let n3= Number(document.getElementById("n3").value)
    let n4= Number(document.getElementById("n4").value)
    let r = (n1 + n2 + n3 + n4)/4
    alert (r)
}
function exe3(){
   let n1 =Number ( document.getElementById ("n1").value) 
   let n2 = Number(document.getElementById ("n2").value)
 let r = (n1 + n2)/2
 if (r < 4){
    alert ("reprovado!")
 }
 else if ( r< 7 ){
    alert ("exame!")
    
 }
 else if( r >= 7){
alert("aprovado!")
 }

}
function exe4(){
    let n1 =Number(document.getElementById("n1").value)
    let n2 = Number(document.getElementById("n2").value)
    if (n1 > n2){
        alert ( n1)
    }
    else if (n2 > n1) {alert( n2)}
}
 function exe5(){
    let n1 = Number(document.getElementById("n1").value)  
    let n2 = Number(document.getElementById("n2").value)
    let n3 = Number(document.getElementById("n3").value)
    if (n1 > n2 > n3) {alert ( n1)}
    else  if(n2 > n1 >n3){alert ( n2)}
    else {alert( n3)}
 }

 function exe6(){
   let n1= Number(document.getElementById("n1").value)
   let n2= Number(document.getElementById("n2").value)
   let op= Number(document.getElementById("op").value)
   switch (op){
      case 1:
         media = (n1 + n2) / 2
         alert(media)
         break;
                  case  2:  
                     if (n1>n2)
                     alert (n1 - n2)
                     else if(n2 > n1)
                     alert (n2 - n1)
                        break;
                               case 3: 
                                  produto =  (n1 * n2)
                                    alert(produto)
                                     break;
                                              case 4:
                                                divisao =(n1/n2)
                                                     alert(divisao)
                                                          break;
                                                         }
   }
   function exe7(){
      let n1= Number(document.getElementById("n1").value)
      let n2= Number(document.getElementById("n2").value)
      let op= Number(document.getElementById("op").value)
      switch (op){
         case 1: 
          let quadrado = n1**n2
      
         alert("o Valor é de: "+quadrado)
         break;
         case 2:
            rquadrada= (n1 * n1)  
            rrquadrada= (n2 * n2)
            alert("o recsuado do primeiro é " + rquadrada +" e a da segunda é " + rrquadrada)
            break;
            case 3:
               case 3:
                  let raizCubica1 = Math.cbrt(n1);
                  let raizCubica2 = Math.cbrt(n2);
               alert("o primeiro é de " +raizCubica1 + " e o segundo é "+ raizCubica2)
               break;

      }
   }

      function exe8(){
         let n1= Number(document.getElementById("n1").value)
         if (n1>500){
            alert( "Você não possui direito á aumento ")
         }
         else if (n1<500){
           let atual = n1;
            let aumentosalario = 30;
            let nsalario = atual * (1 + aumentosalario/100);
            nsalario = Math.ceil(nsalario);
            alert("o seu novo salário é de " + nsalario);
         }


      }
      function exe9(){
      
         let n1= Number(document.getElementById("n1").value)
         if (n1>300){
            let atual=n1;
            let aumentosalario=15;
            let nsalario= atual * (1+ aumentosalario/100);  
            nsalario = Math.ceil(nsalario);
            alert( "seu salário atual é de:  " + nsalario)
         }
         else if (n1<=300){
           let atual= n1;
            let aumentosalario = 35;
            let nsalario = atual * (1 + aumentosalario/100);
            nsalario = Math.ceil(nsalario);
            alert("o seu novo salário é de " + nsalario)}
      }
      function exe10(){
   let n1= Number(document.getElementById("n1").value)
if(n1>400){
   let atual = n1;
   let aumentosalario= 30;
   let nsalario=atual * (1 +  aumentosalario/100);
   nsalario = Math.ceil (nsalario);
   alert("o seu saldo é de: "+ nsalario)
} else if(n1== 400 && 300){
 let atual= n1;
   let aumentosalario= 25;
   let nsalario=atual * (1 +  aumentosalario/100);
   nsalario = Math.ceil (nsalario);
alert(" o seu credito é de: " + nsalario)
}
else if(n1==300 && 200){
   let atual = n1;
   let aumentosalario= 20;
   let nsalario=atual * (1 +  aumentosalario/100);
   nsalario = Math.ceil (nsalario);
   alert("seu crédito é de: " + nsalario)
}
else if (n1<=200){
   let atual = n1;
   let aumentosalario= 10;
   let nsalario=atual * (1 +  aumentosalario/100);
   nsalario = Math.ceil (nsalario);
   alert( "seu crédito é de: " + nsalario)
}

      }
      function exe11(){
         let n1= Number(document.getElementById("n1").value)
         if (n1<=12000){
            let atual= n1;
            let impdistribuidor=5;
            let vtotal= atual * (1 + impdistribuidor/100);
            nsalario = Math.ceil(vtotal)
            alert("O valor será de: "+ vtotal)
         }
          else if (n1 >= 12000 && n1 <= 25000){
            let atual= n1;
            let impdistribuidor =10;
            let impostos=15;  
            let vtotal1 = atual * (1 + impdistribuidor/100);
            let vtotal2 = vtotal1 * (1 + impostos/100);
            vtotal2 = Math.ceil(vtotal2)
            alert("O valor final será de: "+ vtotal2);
         }
         else if (n1 > 25000){
            let n1 = Number(document.getElementById("n1").value)
            let atual= n1
            let impdistribuidor= 15;
            let impostos= 20
            let vtotal1= atual *(1 + impdistribuidor/100)
            let vtotal2 =vtotal1 * (1+ impostos/100)
            vtotal2 = Math.ceil (vtotal2)
            alert ("O valor é de: " + vtotal2)
         }
      }

